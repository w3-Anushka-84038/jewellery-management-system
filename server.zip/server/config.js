module.exports={
    host:'localhost',
    port:3306,
    user:'w3_84038_Anushka',
    password:'anushka',
    database:'project',
    secret:'tjgInw4hMeWdiJyL1WhiB6SjImGnJmRF'
}
